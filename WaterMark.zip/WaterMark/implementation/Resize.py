#import sys
from PIL import Image


def resize_image(inputPath, outPath, newSize):
    with Image.open(inputPath) as image:
        resized_image = image.resize(newSize)
        resized_image.save(outPath)

input_image_path = "H:\Term 8\FPGA\Project\sp.jpg"
outPath = "H:\Term 8\FPGA\Project\el\spider.jpg"
newSize = (500, 500)
resize_image(input_image_path, outPath, newSize)